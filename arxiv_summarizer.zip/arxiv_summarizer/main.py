import os
import time
from typing import List, Dict
from fetch_papers import ArxivPaperFetcher
from download_pdf import PdfDownloader
from extract_text import PdfTextExtractor
from cleanContent import ContentCleaner
from chunk_text import TextChunker
from summarize_chunks import ChunkSummarizer
from generate_final_summary import FinalSummarizer

class ArxivSummarizer:
    def __init__(self):
        os.makedirs("arxiv_papers", exist_ok=True)
        self.fetcher = ArxivPaperFetcher()
        self.downloader = PdfDownloader()
        self.extractor = PdfTextExtractor()
        self.cleaner = ContentCleaner()
        self.chunker = TextChunker()
        self.chunk_summarizer = ChunkSummarizer()
        self.final_summarizer = FinalSummarizer()
    
    def process_papers(self, keyword: str, max_results: int = 10, 
                      sort_by: str = "relevance", filter_by: str = None) -> List[Dict]:
        papers = self.fetcher.fetch_papers(keyword, max_results, sort_by, filter_by)
        
        results = []
        for paper in papers:
            try:
                # Download PDF
                pdf_file = self.downloader.download_pdf(paper['pdf_link'])
                
                # Extract text
                raw_text = self.extractor.extract_text(pdf_file)
                
                # Clean content
                cleaned_text = self.cleaner.clean_text(raw_text)
                
                # Chunk text
                chunks = self.chunker.chunk_text(cleaned_text)
                
                # Summarize chunks
                chunk_summaries = self.chunk_summarizer.summarize_chunks(chunks)
                
                # Generate final summary
                final_summary = self.final_summarizer.generate_final_summary(chunk_summaries)
                
                # Save results
                paper_data = {
                    **paper,
                    "summary": final_summary,
                    "chunk_summaries": chunk_summaries,
                    "content": cleaned_text[:10000]  # First 10k chars
                }
                self._save_paper(paper_data)
                results.append(paper_data)
                
            except Exception as e:
                print(f"Failed to process paper {paper['id']}: {str(e)}")
                results.append({
                    **paper,
                    "summary": "Processing failed",
                    "chunk_summaries": [],
                    "content": ""
                })
        
        return results
    
    def _save_paper(self, paper_data: Dict):
        """Save paper data to a local file"""
        filename = f"arxiv_papers/{paper_data['id']}.txt"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"Title: {paper_data['title']}\n")
            f.write(f"Authors: {', '.join(paper_data['authors'])}\n")
            f.write(f"Published: {paper_data['published']}\n")
            f.write(f"PDF Link: {paper_data['pdf_link']}\n")
            f.write(f"HTML Link: {paper_data['html_link']}\n")
            f.write("\nFinal Summary:\n")
            f.write(paper_data['summary'])
            f.write("\n\nChunk Summaries:\n")
            for title, summary in paper_data['chunk_summaries']:
                f.write(f"\n{title}:\n{summary}\n")
            f.write("\n\nCleaned Content (partial):\n")
            f.write(paper_data['content'])
            f.write("\n")

if __name__ == "__main__":
    summarizer = ArxivSummarizer()
    
    print("arXiv Research Paper Fetcher with Hierarchical PDF Summarization")
    print("-------------------------------------------------------------")
    
    keyword = input("Enter keyword/topic: ")
    max_results = int(input("Number of results (default 10): ") or "10")
    sort_by = input("Sort by (relevance/recency, default relevance): ") or "relevance"
    filter_by = input("Filter by category (optional, e.g., cs.AI): ") or None
    
    sort_by = "lastUpdatedDate" if sort_by.lower() == "recency" else "relevance"
    
    try:
        start_time = time.time()
        print("\nFetching papers and generating summaries...")
        papers = summarizer.process_papers(
            keyword=keyword,
            max_results=max_results,
            sort_by=sort_by,
            filter_by=filter_by
        )
        
        print(f"\nCompleted in {time.time() - start_time:.2f} seconds")
        print("\nResults:")
        for paper in papers:
            print(f"\nTitle: {paper['title']}")
            print(f"Authors: {', '.join(paper['authors'])}")
            print(f"Published: {paper['published']}")
            print(f"PDF Link: {paper['pdf_link']}")
            print(f"HTML Link: {paper['html_link']}")
            print("\nSummary:")
            print(paper['summary'])
            print("\n" + "="*80)
        
        print(f"\nPapers and summaries saved to 'arxiv_papers' directory.")
    except Exception as e:
        print(f"Error: {e}")