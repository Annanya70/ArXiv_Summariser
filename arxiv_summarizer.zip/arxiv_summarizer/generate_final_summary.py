from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

class FinalSummarizer:
    def __init__(self):
        self.tokenizer = AutoTokenizer.from_pretrained("Falconsai/text_summarization")
        self.model = AutoModelForSeq2SeqLM.from_pretrained("Falconsai/text_summarization")
    
    def generate_final_summary(self, chunk_summaries: list[tuple[str, str]]) -> str:
        """Generate final summary from chunk summaries"""
        combined = "\n\n".join(f"{title}:\n{summary}" for title, summary in chunk_summaries)
        combined = combined[:4000]  # Ensure we don't exceed model limits
        
        inputs = self.tokenizer(combined, return_tensors="pt", truncation=True, max_length=1024)
        summary_ids = self.model.generate(
            inputs["input_ids"],
            max_length=500,
            min_length=100,
            length_penalty=2.0,
            num_beams=4,
            early_stopping=True
        )
        return self.tokenizer.decode(summary_ids[0], skip_special_tokens=True)