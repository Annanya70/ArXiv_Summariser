from typing import List, Dict, Union

class TextChunker:
    @staticmethod
    def chunk_text(text: str, chunk_size: int = 2000, overlap: int = 200) -> List[str]:
        """
        Split text into chunks with overlap for context preservation
        Returns simple list of chunks for pipeline compatibility
        """
        if overlap >= chunk_size:
            raise ValueError("Overlap must be smaller than chunk size")
        
        if not text or not text.strip():
            return []
            
        chunks = []
        start = 0
        text_length = len(text)
        
        while start < text_length:
            # Calculate the end position for this chunk
            end = min(start + chunk_size, text_length)
            
            # Try to find a sentence boundary near the end
            if end < text_length:
                # Look backwards from end position for sentence boundaries
                search_start = max(start + chunk_size // 2, start + 100)
                
                for i in range(end - 1, search_start - 1, -1):
                    if text[i] in {'.', '!', '?', '\n'}:
                        end = i + 1
                        break
            
            # Extract the chunk
            chunk = text[start:end].strip()
            if chunk:  # Only add non-empty chunks
                chunks.append(chunk)
            
            # Calculate next start position with overlap
            next_start = end - overlap
            start = max(next_start, start + 1)  # Always advance at least 1 character
            
            # Safety checks to prevent infinite loops
            if start >= text_length:
                break
                
            # Handle remaining small text
            remaining_length = text_length - start
            if remaining_length < chunk_size // 4 and remaining_length > 0:
                remaining_text = text[start:].strip()
                if remaining_text and len(remaining_text) > 50:
                    chunks.append(remaining_text)
                break
        
        print(f"Created {len(chunks)} chunks from text of length {text_length}")
        return chunks
    
    @staticmethod
    def chunk_text_with_details(text: str, chunk_size: int = 2000, overlap: int = 200) -> Dict:
        """
        Split text into chunks with overlap and return detailed information
        For debugging and analysis purposes
        """
        if overlap >= chunk_size:
            raise ValueError("Overlap must be smaller than chunk size")
        
        if not text or not text.strip():
            return {"chunks": [], "details": [], "total_chunks": 0, "original_text_length": 0}
            
        chunks = []
        chunk_details = []
        start = 0
        text_length = len(text)
        
        while start < text_length:
            # Calculate the end position for this chunk
            end = min(start + chunk_size, text_length)
            original_end = end
            
            # Try to find a sentence boundary near the end
            sentence_boundary_found = False
            if end < text_length:
                search_start = max(start + chunk_size // 2, start + 100)
                
                for i in range(end - 1, search_start - 1, -1):
                    if text[i] in {'.', '!', '?', '\n'}:
                        end = i + 1
                        sentence_boundary_found = True
                        break
            
            # Extract the chunk
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
                
                # Calculate overlap with previous chunk
                overlap_with_prev = 0
                if len(chunks) > 1:
                    prev_chunk = chunks[-2]
                    # Simple overlap calculation
                    overlap_start = max(0, start - overlap)
                    if overlap_start < len(prev_chunk):
                        overlap_with_prev = min(overlap, len(prev_chunk) - overlap_start)
                
                chunk_details.append({
                    "chunk_number": len(chunks),
                    "start_pos": start,
                    "end_pos": end,
                    "original_end": original_end,
                    "length": len(chunk),
                    "sentence_boundary_used": sentence_boundary_found,
                    "overlap_with_previous": overlap_with_prev,
                    "starts_with": chunk[:50] + "..." if len(chunk) > 50 else chunk,
                    "ends_with": "..." + chunk[-50:] if len(chunk) > 50 else chunk
                })
            
            # Calculate next start position
            next_start = end - overlap
            start = max(next_start, start + 1)
            
            # Safety checks
            if start >= text_length:
                break
                
            remaining_length = text_length - start
            if remaining_length < chunk_size // 4 and remaining_length > 0:
                remaining_text = text[start:].strip()
                if remaining_text and len(remaining_text) > 50:
                    chunks.append(remaining_text)
                    chunk_details.append({
                        "chunk_number": len(chunks),
                        "start_pos": start,
                        "end_pos": text_length,
                        "original_end": text_length,
                        "length": len(remaining_text),
                        "sentence_boundary_used": False,
                        "overlap_with_previous": 0,
                        "starts_with": remaining_text[:50] + "..." if len(remaining_text) > 50 else remaining_text,
                        "ends_with": "..." + remaining_text[-50:] if len(remaining_text) > 50 else remaining_text,
                        "note": "Final remaining chunk"
                    })
                break
        
        return {
            "chunks": chunks,
            "details": chunk_details,
            "total_chunks": len(chunks),
            "original_text_length": text_length,
            "chunk_size": chunk_size,
            "overlap": overlap
        }
    
    @staticmethod
    def display_all_chunks(result: Union[List[str], Dict], show_full_text: bool = True, show_overlap_analysis: bool = False):
        """Display all chunks with optional detailed information"""
        
        # Handle both simple list and detailed dict formats
        if isinstance(result, list):
            chunks = result
            print("="*80)
            print(f"TEXT CHUNKING RESULTS")
            print("="*80)
            print(f"Total chunks created: {len(chunks)}")
            print("="*80)
            
            for i, chunk in enumerate(chunks):
                print(f"\n{'='*15} CHUNK {i+1} {'='*15}")
                print(f"Length: {len(chunk)} characters")
                
                if show_full_text:
                    print(f"\nFULL CHUNK TEXT:")
                    print("-" * 50)
                    print(chunk)
                    print("-" * 50)
                else:
                    print(f"Preview: {chunk[:100]}{'...' if len(chunk) > 100 else ''}")
            
        elif isinstance(result, dict):
            chunks = result["chunks"]
            details = result["details"]
            
            print("="*100)
            print(f"DETAILED TEXT CHUNKING ANALYSIS")
            print("="*100)
            print(f"Original text length: {result['original_text_length']} characters")
            print(f"Chunk size: {result['chunk_size']} characters")
            print(f"Overlap: {result['overlap']} characters")
            print(f"Total chunks created: {result['total_chunks']}")
            print("="*100)
            
            for i, (chunk, detail) in enumerate(zip(chunks, details)):
                print(f"\n{'='*20} CHUNK {i+1} {'='*20}")
                print(f"Position: {detail['start_pos']} - {detail['end_pos']}")
                print(f"Length: {detail['length']} characters")
                print(f"Sentence boundary used: {detail['sentence_boundary_used']}")
                if detail['overlap_with_previous'] > 0:
                    print(f"Overlap with previous: {detail['overlap_with_previous']} characters")
                if 'note' in detail:
                    print(f"Note: {detail['note']}")
                
                if show_full_text:
                    print(f"\nFULL CHUNK TEXT:")
                    print("-" * 50)
                    print(chunk)
                    print("-" * 50)
                else:
                    print(f"\nStarts with: {detail['starts_with']}")
                    print(f"Ends with: {detail['ends_with']}")
                
                if show_overlap_analysis and i > 0 and detail['overlap_with_previous'] > 0:
                    print(f"\nOVERLAP ANALYSIS:")
                    print(f"Estimated overlap: {detail['overlap_with_previous']} characters")

# Pipeline integration functions
def process_text_pipeline(text: str, chunk_size: int = 2000, overlap: int = 200, verbose: bool = False) -> List[str]:
    """
    Process text through the chunking pipeline
    Returns list of chunks ready for summarization
    """
    chunker = TextChunker()
    
    if verbose:
        print("Starting text chunking process...")
        print(f"Input text length: {len(text)} characters")
    
    chunks = chunker.chunk_text(text, chunk_size, overlap)
    
    if verbose:
        print(f"Chunking completed: {len(chunks)} chunks created")
        chunker.display_all_chunks(chunks, show_full_text=False)
    
    return chunks

# Test the pipeline integration
if __name__ == "__main__":
    # Test text
    sample_text = """Artificial Intelligence and Machine Learning have revolutionized numerous industries in recent years. The rapid advancement in computational power and algorithmic sophistication has enabled unprecedented breakthroughs in various domains.

Deep learning, a subset of machine learning, has particularly shown remarkable success in image recognition, natural language processing, and speech recognition tasks. Convolutional Neural Networks (CNNs) have become the backbone of computer vision applications, while Recurrent Neural Networks (RNNs) and Transformers have transformed how we approach sequential data processing.

The introduction of attention mechanisms has been a game-changer in the field. The famous "Attention is All You Need" paper introduced the Transformer architecture, which has since become the foundation for large language models like GPT, BERT, and their successors. These models have demonstrated human-like capabilities in text generation, translation, and comprehension.

However, with great power comes great responsibility. The deployment of AI systems raises important ethical considerations including bias, fairness, transparency, and accountability. Researchers and practitioners must work together to ensure that AI benefits society while minimizing potential harms.

The future of AI looks incredibly promising, with ongoing research in areas such as few-shot learning, multimodal learning, and artificial general intelligence. As we continue to push the boundaries of what's possible, it's crucial to maintain a balance between innovation and responsible development."""
    
    # Test simple chunking (for pipeline)
    print("TESTING SIMPLE CHUNKING (Pipeline Compatible)")
    print("=" * 60)
    
    chunker = TextChunker()
    simple_chunks = chunker.chunk_text(sample_text, chunk_size=500, overlap=100)
    chunker.display_all_chunks(simple_chunks, show_full_text=True)
    
    print("\n" + "=" * 60)
    print("TESTING DETAILED CHUNKING (Analysis)")
    print("=" * 60)
    
    detailed_result = chunker.chunk_text_with_details(sample_text, chunk_size=500, overlap=100)
    chunker.display_all_chunks(detailed_result, show_full_text=False, show_overlap_analysis=True)
    
    # Test pipeline function
    print("\n" + "=" * 60)
    print("TESTING PIPELINE FUNCTION") 
    print("=" * 60)
    
    pipeline_chunks = process_text_pipeline(sample_text, chunk_size=400, overlap=80, verbose=True)
    print(f"\nPipeline returned {len(pipeline_chunks)} chunks ready for summarization")