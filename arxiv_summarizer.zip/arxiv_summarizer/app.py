import streamlit as st
import os
import tempfile
from io import BytesIO
from typing import Dict
from fetch_papers import ArxivPaperFetcher
from download_pdf import PdfDownloader
from extract_text import PdfTextExtractor
from cleanContent import ContentCleaner
from chunk_text import TextChunker
from summarize_chunks import ChunkSummarizer
from generate_final_summary import FinalSummarizer

# Initialize all components
@st.cache_resource
def get_components():
    return {
        "fetcher": ArxivPaperFetcher(),
        "downloader": PdfDownloader(),
        "extractor": PdfTextExtractor(),
        "cleaner": ContentCleaner(),
        "chunker": TextChunker(),
        "chunk_summarizer": ChunkSummarizer(),
        "final_summarizer": FinalSummarizer()
    }

def process_pdf_content(pdf_content, components) -> Dict:
    """Process PDF content through the pipeline"""
    try:
        # Extract text
        raw_text = components["extractor"].extract_text(pdf_content)
        
        # Clean content
        cleaned_text = components["cleaner"].clean_text(raw_text)
        
        # Chunk text
        chunks = components["chunker"].chunk_text(cleaned_text)
        
        # Summarize chunks
        chunk_summaries = components["chunk_summarizer"].summarize_chunks(chunks)
        
        # Generate final summary
        final_summary = components["final_summarizer"].generate_final_summary(chunk_summaries)
        
        return {
            "status": "success",
            "summary": final_summary,
            "chunk_summaries": chunk_summaries,
            "content": cleaned_text[:10000]  # First 10k chars
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e)
        }

def main():
    st.set_page_config(page_title="PDF Summarizer", layout="wide")
    components = get_components()
    
    st.title("📄 Advanced PDF Summarizer")
    st.markdown("Summarize research papers using different input methods")
    
    # Create tabs for different input methods
    tab1, tab2, tab3 = st.tabs([
        "🔍 Search arXiv by Keyword", 
        "📎 Paste PDF URL", 
        "⬆️ Upload PDF File"
    ])
    
    with tab1:
        st.subheader("Search arXiv Papers")
        keyword = st.text_input("Enter research topic/keyword:", key="keyword_input")
        col1, col2 = st.columns(2)
        with col1:
            max_results = st.slider("Number of results", 1, 10, 3, key="max_results")
        with col2:
            sort_by = st.radio("Sort by", ["relevance", "recency"], key="sort_by")
        
        filter_by = st.text_input("Filter by category (optional, e.g., cs.AI):", key="filter_by")
        
        if st.button("Search and Summarize", key="search_button"):
            if not keyword:
                st.warning("Please enter a keyword/topic")
            else:
                with st.spinner("Fetching papers and generating summaries..."):
                    try:
                        papers = components["fetcher"].fetch_papers(
                            keyword=keyword,
                            max_results=max_results,
                            sort_by="lastUpdatedDate" if sort_by == "recency" else "relevance",
                            filter_by=filter_by if filter_by else None
                        )
                        
                        for paper in papers:
                            with st.expander(f"📄 {paper['title']}"):
                                st.write(f"**Authors:** {', '.join(paper['authors'])}")
                                st.write(f"**Published:** {paper['published']}")
                                
                                # Process each paper
                                pdf_content = components["downloader"].download_pdf(paper['pdf_link'])
                                result = process_pdf_content(pdf_content, components)
                                
                                if result["status"] == "success":
                                    st.subheader("Summary")
                                    st.write(result["summary"])
                                    
                                    with st.expander("View detailed chunk summaries"):
                                        for title, summary in result["chunk_summaries"]:
                                            st.write(f"**{title}**")
                                            st.write(summary)
                                            st.write("---")
                                else:
                                    st.error(f"Failed to process paper: {result['message']}")
                                
                                st.markdown(f"[View on arXiv]({paper['html_link']}) | [Download PDF]({paper['pdf_link']})")
                    except Exception as e:
                        st.error(f"Error: {str(e)}")
    
    with tab2:
        st.subheader("Summarize from PDF URL")
        pdf_url = st.text_input("Enter PDF URL:", key="pdf_url")
        
        if st.button("Summarize URL", key="url_button"):
            if not pdf_url:
                st.warning("Please enter a PDF URL")
            else:
                with st.spinner("Processing PDF..."):
                    try:
                        pdf_content = components["downloader"].download_pdf(pdf_url)
                        result = process_pdf_content(pdf_content, components)
                        
                        if result["status"] == "success":
                            st.subheader("Summary")
                            st.write(result["summary"])
                            
                            with st.expander("View detailed chunk summaries"):
                                for title, summary in result["chunk_summaries"]:
                                    st.write(f"**{title}**")
                                    st.write(summary)
                                    st.write("---")
                        else:
                            st.error(f"Failed to process PDF: {result['message']}")
                    except Exception as e:
                        st.error(f"Error: {str(e)}")
    
    with tab3:
        st.subheader("Upload PDF File")
        uploaded_file = st.file_uploader("Choose a PDF file", type="pdf", key="file_uploader")
        
        if uploaded_file is not None and st.button("Summarize Uploaded PDF", key="upload_button"):
            with st.spinner("Processing PDF..."):
                try:
                    # Create in-memory file
                    pdf_content = BytesIO(uploaded_file.getvalue())
                    result = process_pdf_content(pdf_content, components)
                    
                    if result["status"] == "success":
                        st.subheader("Summary")
                        st.write(result["summary"])
                        
                        with st.expander("View detailed chunk summaries"):
                            for title, summary in result["chunk_summaries"]:
                                st.write(f"**{title}**")
                                st.write(summary)
                                st.write("---")
                    else:
                        st.error(f"Failed to process PDF: {result['message']}")
                except Exception as e:
                    st.error(f"Error: {str(e)}")

if __name__ == "__main__":
    main()