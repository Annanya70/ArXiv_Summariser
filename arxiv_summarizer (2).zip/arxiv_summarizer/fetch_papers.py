import requests
import feedparser
from typing import List, Dict

class ArxivPaperFetcher:
    def __init__(self):
        self.base_url = "http://export.arxiv.org/api/query?"
    
    def fetch_papers(self, keyword: str, max_results: int = 10, 
                    sort_by: str = "relevance", filter_by: str = None) -> List[Dict]:
        """Fetch papers from arXiv based on keyword/topic"""
        query = f"search_query=all:{keyword}"
        query += f"&sortBy={sort_by}"
        query += f"&max_results={max_results}"
        
        if filter_by:
            query += f"+AND+cat:{filter_by}"
        
        url = self.base_url + query
        response = requests.get(url)
        
        if response.status_code != 200:
            raise Exception(f"Failed to fetch papers. Status code: {response.status_code}")
        
        feed = feedparser.parse(response.content)
        papers = []
        
        for entry in feed.entries:
            paper_id = entry.id.split('/')[-1]
            papers.append({
                "id": paper_id,
                "title": entry.title,
                "authors": [author.name for author in entry.authors],
                "published": entry.published,
                "pdf_link": f"https://arxiv.org/pdf/{paper_id}.pdf",
                "html_link": f"https://arxiv.org/abs/{paper_id}"
            })
        
        return papers