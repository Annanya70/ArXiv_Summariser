from PyPDF2 import PdfReader
from io import BytesIO

class PdfTextExtractor:
    @staticmethod
    def extract_text(pdf_file: BytesIO, page_limit: int = 10) -> str:
        """Extract text from PDF file"""
        pdf_reader = PdfReader(pdf_file)
        text = ""
        for page in pdf_reader.pages[:page_limit]:
            text += page.extract_text() + "\n"

        
        return text