from typing import List, Tuple
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

class ChunkSummarizer:
    def __init__(self):
        self.tokenizer = AutoTokenizer.from_pretrained("Falconsai/text_summarization")
        self.model = AutoModelForSeq2SeqLM.from_pretrained("Falconsai/text_summarization")
    
    def summarize_chunks(self, chunks: List[str]) -> List[Tuple[str, str]]:
        """Generate summaries for all chunks of text"""
        summaries = []
        for i, chunk in enumerate(chunks):
            try:
                summary = self._generate_summary(chunk)
                summaries.append((f"Chunk {i+1}", summary))
            except Exception as e:
                print(f"Failed to summarize chunk {i+1}: {str(e)}")
                summaries.append((f"Chunk {i+1}", "Summary failed"))
        print(summaries)        
        return summaries
    
    def _generate_summary(self, text: str, max_length: int = 300) -> str:
        """Generate summary for a single chunk"""
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=1024)
        summary_ids = self.model.generate(
            inputs["input_ids"],
            max_length=max_length,
            min_length=30,
            length_penalty=2.0,
            num_beams=4,
            early_stopping=True
        )
        return self.tokenizer.decode(summary_ids[0], skip_special_tokens=True)