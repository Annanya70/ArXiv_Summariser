import re

class ContentCleaner:
    @staticmethod
    def clean_text(text: str) -> str:
        """Clean the extracted text by removing references and unwanted sections"""
        patterns = [
            (r'\n\s*References?\s*\n.*', ''),  # References section
            (r'\n\s*Bibliography\s*\n.*', ''),  # Bibliography
            (r'\[\d+\]|\[\d+\-\d+\]', ''),  # Citations
            (r'\S+@\S+', ''),  # Email addresses
            (r'http\S+|www\S+', ''),  # URLs
            (r'\n\s*\n', '\n\n'),  # Multiple newlines
            (r'(Figure|Fig|Table)\s+\d+[.:].*?\n', ''),  # Captions
            (r'\$.*?\$', ''),  # Math equations
            (r'\n\d+\s*\n', '\n'),  # Page numbers
            (r'arXiv:\d+\.\d+v\d+.*?\n', '')  # arXiv identifier
        ]

        for pattern, replacement in patterns:
            text = re.sub(pattern, replacement, text, flags=re.DOTALL | re.IGNORECASE)
        return text.strip()